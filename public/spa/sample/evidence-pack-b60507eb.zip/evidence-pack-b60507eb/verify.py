#!/usr/bin/env python3
"""ProofMark Evidence Pack — RFC3161 Verifier (Python+OpenSSL)"""
import sys, hashlib, subprocess, pathlib

def main(argv):
    if len(argv) < 2:
        print("Usage: verify.py <original-file>", file=sys.stderr)
        sys.exit(2)
    orig = pathlib.Path(argv[1])
    expected = open("hash.txt").read().split("=")[1].strip()
    actual = hashlib.sha256(orig.read_bytes()).hexdigest()
    if actual.lower() != expected.lower():
        print(f"[HASH] MISMATCH expected={expected} actual={actual}", file=sys.stderr)
        sys.exit(3)
    print(f"[HASH] OK {actual}")
    r = subprocess.run([
        "openssl","ts","-verify",
        "-in","timestamp.tsr","-digest", expected,
        "-CAfile","freetsa-ca.crt","-untrusted","freetsa-tsa.crt"
    ], capture_output=True, text=True)
    print(r.stdout.strip())
    if "Verification: OK" not in r.stdout:
        print(r.stderr, file=sys.stderr)
        sys.exit(4)

if __name__ == "__main__":
    main(sys.argv)