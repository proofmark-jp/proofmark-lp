#!/usr/bin/env bash
# ProofMark Evidence Pack — RFC3161 Verifier (OpenSSL)
set -euo pipefail
HASH=$(awk -F"= " "/^SHA256/ {print \$2}" hash.txt)

if [ -z "$HASH" ]; then
  echo "Cannot read SHA-256 from hash.txt" >&2
  exit 1
fi

ORIG="${1:-}"
if [ -n "$ORIG" ] && [ -f "$ORIG" ]; then
  ACTUAL=$(openssl dgst -sha256 "$ORIG" | awk "{print \$2}")
  echo "[HASH] expected=$HASH"
  echo "[HASH] actual  =$ACTUAL"
  if [ "$HASH" != "$ACTUAL" ]; then
    echo "[HASH] MISMATCH" >&2
    exit 2
  fi
fi

openssl ts -verify \
  -in timestamp.tsr \
  -digest "$HASH" \
  -CAfile freetsa-ca.crt \
  -untrusted freetsa-tsa.crt

echo "[TST] OK"