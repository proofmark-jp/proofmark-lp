---
tags: [dr, disaster-recovery, backup, incident-response, supabase, vercel]
aliases: [Disaster-Recovery, 災害復旧プロトコル]
date: 2026-06-14
---
# 03_Disaster-Recovery (インフラ完全崩壊とヒューマンエラーからの復旧プロトコル)

本ドキュメントは、ProofMarkのシステムが「物理的・論理的に完全に破壊された状態」から、ビジネスの息の根を繋ぐための冷徹な蘇生手順（Disaster Recovery）を定義する。
障害発生時にファウンダーが「考える」ことは許されない。以下のプロトコルを機械的に実行するのみである。

## 1. The "Fat-Finger" Defense (ファウンダー自身のミスへの防衛)
Sinn自身が誤って本番のデータベースレコードを削除した、あるいは致命的なバグをPushしてデータが破損した場合の復旧プロトコル。

*   **Point-in-Time Recovery (PITR) の絶対要件:**
    *   本番環境の Supabase プロジェクトにおいては、必ず Pro プラン（課金）にアップグレードし、**PITR（秒単位の巻き戻し機能）**を有効化する。インフラ原価を抑えるProofMarkにおいて、これだけは絶対にケチってはいけない「命綱」である。
*   **Cold Standby Backup (Mac mini への異次元退避):**
    *   Supabase（クラウド）自体へのアクセス権が喪失した場合に備え、Mac mini上の `Agent-DevOps` に、毎日深夜3時に `pg_dump` コマンドを発行させ、全ユーザーのハッシュ台帳（テキストデータのみ）をローカルストレージへPull（退避）させる。
    *   万が一Supabaseが消滅しても、このローカルダンプさえあれば、別のアカウントでDBを再構築し、SaaSを1時間で蘇生できる。

## 2. Cloud Region Death (クラウドの広域障害・インフラ全停止)
Vercelのグローバルダウン、またはSupabaseがホストされているAWSリージョンの完全停止など、自力ではどうにもならない外部インフラの死に対する防衛プロトコル。

*   **Cloudflare Fail-Whale (DNSレベルの死んだふり):**
    *   VercelやSupabaseのダッシュボードにアクセスして復旧を祈るような無駄な時間は過ごさない。
    *   障害を検知した瞬間、Cloudflare（Vercelのさらに外側のDNS/プロキシ層）のトグルスイッチを手動（将来は `Agent-SecOps` が自動）で切り替え、すべてのトラフィックを静的な「Maintenance / Read-Only ページ」へとルーティングする。
    *   これにより、障害中にユーザーが中途半端なアップロードを行い、ステート（状態）が破損することを物理的に防ぐ。
*   **Silence & Asynchronous Recovery:**
    *   障害対応中、X（旧Twitter）等でパニック気味に「現在調査中です！」と連投することはしない。「Cloudflareのメンテナンス画面」が最大の広報である。インフラベンダーが復旧したことを確認してから、ルーティングを静かに元に戻す。

## 3. The "Kill Switch" (キー漏洩時の即時切断)
万が一、`SUPABASE_SERVICE_ROLE_KEY` や、将来実装するC2PAの署名用秘密鍵がGitHub等に誤って公開（Leak）されてしまった場合のプロトコル。

*   **Zero-Hesitation Rotation (躊躇なき鍵のローテーション):**
    *   漏洩を検知した瞬間に実行する「Kill Switch（ワンクリック・シェルスクリプト）」をローカルのMac環境に事前に準備しておく。
    *   このスクリプトは以下の3つを10秒以内に全自動で実行する。
        1. Vercel API を叩き、すべての環境変数をダミー文字列で上書きして強制再デプロイ（バックエンドの無力化）。
        2. Supabase API を叩き、データベースのパスワードとJWTシークレットを強制再生成。
        3. Upstash Redis に `FLUSHALL` を発行し、全ユーザーのセッションとキャッシュを強制破棄（全員を強制ログアウト）。
*   **事後対応:** 鍵の再設定が終わりシステムを再始動させるまで、サービスは完全にダウンするが、「全件流出」や「不正な証明書の無限発行」に比べれば遥かに安い代償である。

## 4. WORM (Write Once, Read Many) 台帳の不変性保証
障害から復旧した際、最も重要なのは「過去の証明ハッシュが一切改ざんされていないこと」の保証である。

*   **Idempotent Sync (冪等な同期):**
    *   フロントエンド（IndexedDB）から送られてくる未処理のペイロードが、障害明けに一斉にバックエンドに再送される。APIは必ず「ハッシュ値の重複チェック」を行い、二重登録を無視する冪等性（Idempotency）を厳格に維持する。


## 🔗 Connected Nodes
- [[ADR-006-Adopt-Optimistic-UI-and-Local-First-State]]
- [[Agent-DevOps]]